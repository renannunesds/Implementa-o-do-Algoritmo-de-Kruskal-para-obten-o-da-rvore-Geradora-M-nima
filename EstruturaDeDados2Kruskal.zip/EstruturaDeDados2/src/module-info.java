/**
 * 
 */
/**
 * 
 */
module EstruturaDeDados2 {
	requires java.desktop;
}